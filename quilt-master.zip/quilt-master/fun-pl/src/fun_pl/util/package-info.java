/**
 * 
 */
/**
 * @author jgomez
 *
 */
package fun_pl.util;