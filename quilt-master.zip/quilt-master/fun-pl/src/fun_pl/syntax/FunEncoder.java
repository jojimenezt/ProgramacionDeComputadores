package fun_pl.syntax;

import fun_pl.util.FunConstants;
import unalcol.language.LanguageException;
import unalcol.language.symbol.Encoder;
import unalcol.util.I18N;

public class FunEncoder implements Encoder{

	protected String symbols;
	protected String space=" \t\r";
	
	public FunEncoder( String symbols ) throws LanguageException{
		this.symbols = symbols;
		if(symbols.length()>FunConstants.END_LINK_SYMBOLS) 
			throw new LanguageException(FunConstants.extra, symbols.substring(FunConstants.START_LINK_SYMBOLS), 
					(FunConstants.END_LINK_SYMBOLS-FunConstants.START_LINK_SYMBOLS));
	} 
	
	@Override
	public int apply(Integer c) { return apply((int)c); }

	public int apply(int c) {
		if(c==FunConstants.EOF) return FunConstants.EOF;
		int index=symbols.indexOf((char)c);
		if( index>=0 ) return index;
		if( Character.isUpperCase(c)) return FunConstants.UPPER_CASE;
		if( Character.isLowerCase(c)) return FunConstants.LOWER_CASE;
		if( Character.isDigit(c)) return FunConstants.DIGIT;
		if( space.indexOf(c)>=0 ) return FunConstants.SPACE;
		if(c=='\n') return FunConstants.EOL;
		return FunConstants.EXTRA;
	}
	
	public char symbol( int index ){
		if( 0<=index && index <symbols.length() ) return symbols.charAt(index);
		return (char)-1;
	}
	
	public int symbols_number(){ return symbols.length(); }
	
	public static char get_symbol(int index){ return I18N.get(FunConstants.code).charAt(index); }
}